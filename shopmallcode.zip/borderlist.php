 <?include "top.html"; ?>
<table align=center border=0 width=400 style='position:absolute; top:300px;left:650px;'>
<tr><td colspan=2><center><h2><b>��ȸ�� �ֹ���ȸ</b></h2></center></td></tr></table>
<table align=center border=0 width=400 style='position:absolute; top:350px;left:650px;'>

<form method=post action=border.php >
<tr><td align=right><font size=2>��ȭ��ȣ</td>
<td align=left><input type=text   size=20 name=mphone></td></tr>
<tr><td align=right><font size=2>�ֹ���ȣ</td>
<td align=left><input type=text   size=40 name=order></td></tr>
<tr><td align=center colspan=2><input type=submit value='�ֹ�������ȸ'></tr>
</form>
</table>