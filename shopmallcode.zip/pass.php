<?
echo ("
   <form method=post   action='pass2.php?board=$board&id=$id&mode=$mode&user=$UserID'>
   <table border=0 width=400 align=center>
   <tr><td align=center>��ȣ�� �Է��ϼ���</td></tr>
   <tr><td align=center>��ȣ: <input type=password size=15 name='pass'>
   <input type=submit value=�Է�></td></tr>
   </form>
   </table>
");
?>
