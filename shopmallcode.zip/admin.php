
<? include ("top.html"); ?>
<table border=0 width=500 align=center style='margin-top:250px;'>
<tr><td align=center><b>*** ���� �޴�  ***</b></td></tr>
</table>
<table border=1 width=1000 align=center style='margin-top:30px;'>
<tr><td  align=center><font size=2><b>[ȸ �� �� ��]</b></td>
     
      <td  align=center><font size=2><b>[�� ǰ �� ��]</b></td>

	<td  align=center><font size=2><b>[�� �� �� ��]</b></td>
</tr>
<tr><td align=center ><a href=membershow.php><button><i class='fa-sharp fa-solid fa-id-card-clip fa-6x'></i></button></a></td>
	 <td align=center ><a href='p-input.php'><button><i class='fa-sharp fa-solid fa-square-plus fa-6x'></i></button></a></td>

      <td align=center  ><a href=orderlist.php><button ><i class='fa-sharp fa-solid fa-clipboard-list fa-6x' ></i></button></a></td>
</tr>	  
<tr><td align=center>&nbsp;</td>
      <td>&nbsp;</td>
	<td align=center><a href=p-adminlist.php><font size=2>�ǸŻ�ǰ ����/����</a></td>
      <td>&nbsp;</td>
	<td>&nbsp;</td>
</tr>	  
</table>
